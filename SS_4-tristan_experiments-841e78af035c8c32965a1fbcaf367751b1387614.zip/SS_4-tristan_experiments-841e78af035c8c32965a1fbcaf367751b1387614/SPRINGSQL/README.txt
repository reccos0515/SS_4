A spring app that connects to a MySql database.
