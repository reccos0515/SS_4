A Spring app that connects to a MySQL database. 
